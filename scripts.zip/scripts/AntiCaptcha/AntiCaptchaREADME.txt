
   1)
      Edit the tool config file "AntiCaptchaConfigs.txt".
      If you want to, you can also rename it.

   2)
      Create a shortcut to start the .exe.
      Set the target of the shortcut to: "X:\MyPath\AntiCaptcha.exe <HERE YOUR CONFIG FILE>".
      Example: "C:\AntiCaptcha\AntiCaptcha.exe \AntiCaptchaConfigs.txt".
      For the argument you can use "\AntiCaptcha.txt" or "/AntiCaptcha.txt" or "X:\AntiCaptcha.txt".

   3)
      Start the shortcut file.

   4)
      Now you can use the l2net class "AntiCaptcha" to interact with the tool.
      Start "AntiCaptchaTest.l2s" to check it out.
